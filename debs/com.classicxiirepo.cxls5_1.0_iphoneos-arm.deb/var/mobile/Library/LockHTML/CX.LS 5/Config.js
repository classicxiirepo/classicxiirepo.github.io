/*
Configurations
Credits: Original code by Dacal & Junesiphone
*/

var Clock = "12h"; // 12h or 24h
var Lang = "en";  // "en", "fr", "de", "sp", "cz", "nl"

var weathercode = 'USIL0373';  // zip code or weather.com 
var celsius = false;
var gpsswitch = false;
var refreshrate = 10;   // update weather in minutes
