

var Lang = "en";	           // choose between "ca", "en" or "fr".