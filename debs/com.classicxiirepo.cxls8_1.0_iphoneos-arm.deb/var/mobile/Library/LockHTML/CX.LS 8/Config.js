/*
Configurations Here!
Credits: Original code by Dacal & Junesiphone
*/

var Clock = "12h"; // 12h or 24h

